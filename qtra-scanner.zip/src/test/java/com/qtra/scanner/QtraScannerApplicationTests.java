package com.qtra.scanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QtraScannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
